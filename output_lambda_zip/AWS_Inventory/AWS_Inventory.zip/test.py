list1 =  [
  {
    "Key1": "Value1"
  },
  {
    "Key2": "Value2"
  }
]

list2 =  [
  {
    "Key3": "Value3"
  },
  {
    "Key4": "Value4"
  }
]

empty_list = []

for index in list1:  
  empty_list.append(index)
for index in list2:  
  empty_list.append(index)

print(empty_list)
